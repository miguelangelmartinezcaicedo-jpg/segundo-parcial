import networkx as nx
import matplotlib.pyplot as plt

# Crear el grafo
G = nx.Graph()

# Personas de cada comunidad
familia = ["Mamá Liliana", "Papá Juan", "Hermana Dayana", "Hermano Sebas"]
barrio = ["Esteban", "Luis", "Nicolas", "Cristian"]
universidad = ["Sebitas", "Johansu", "Arriguidiguidiguidi",
               "Dieguito", "Alejo"]
centro = "Miguel"

# Agregar las personas
G.add_node(centro)
G.add_nodes_from(familia)
G.add_nodes_from(barrio)
G.add_nodes_from(universidad)

# Conectar a Miguel con todos
for persona in familia + barrio + universidad:
    G.add_edge(centro, persona)

# Conexiones entre las personas de cada comunidad
G.add_edges_from([
    ("Mamá Liliana", "Papá Juan"),
    ("Mamá Liliana", "Hermana Dayana"),
    ("Papá Juan", "Hermano Sebas"),
    ("Hermana Dayana", "Hermano Sebas"),

    ("Esteban", "Luis"),
    ("Luis", "Nicolas"),
    ("Nicolas", "Cristian"),
    ("Esteban", "Cristian"),

    ("Sebitas", "Johansu"),
    ("Johansu", "Arriguidiguidiguidi"),
    ("Arriguidiguidiguidi", "Dieguito"),
    ("Dieguito", "Alejo"),
    ("Sebitas", "Alejo")
])

# Colores para diferenciar las comunidades
colores = []
for persona in G.nodes():
    if persona == centro:
        colores.append("#f4c542")
    elif persona in familia:
        colores.append("#83b5e8")
    elif persona in barrio:
        colores.append("#8bcf9b")
    else:
        colores.append("#e6a0c4")

# Ubicación de las personas en mi grafo
pos = {
    "Miguel": (0, 0),

    "Mamá Liliana": (-2.4, 1.5),
    "Papá Juan": (-1.2, 2.2),
    "Hermana Dayana": (-2.5, 0.3),
    "Hermano Sebas": (-1.2, 0.8),

    "Esteban": (2.1, 1.8),
    "Luis": (3.0, 1.0),
    "Nicolas": (2.8, -0.1),
    "Cristian": (1.8, 0.4),

    "Sebitas": (-1.9, -1.6),
    "Johansu": (-0.8, -2.2),
    "Arriguidiguidiguidi": (0.4, -2.4),
    "Dieguito": (1.4, -1.8),
    "Alejo": (0.2, -1.2)
}

# Dibujo de mi grafo
plt.figure(figsize=(12, 9))

nx.draw_networkx_edges(G, pos, edge_color="gray",
                       width=1.5, alpha=0.75)

nx.draw_networkx_nodes(G, pos, node_color=colores,
                       node_size=2100, edgecolors="black")

nx.draw_networkx_labels(G, pos, font_size=9,
                        font_weight="bold")

plt.title("Mi red social personal - Miguel")
plt.axis("off")
plt.tight_layout()
plt.savefig("red_social_miguel.png")
plt.show()